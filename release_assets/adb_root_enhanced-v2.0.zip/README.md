# ADB Root Enhanced

Android 9/10/11/12+ support. Enhanced version with modern Android compatibility.

You don't need this module if you don't know what is "adb root". It's not an
ordinary root (su), it's the adbd daemon running on your phone with root rights.
adb root allows you to "adb push/pull" to system directories and run such commands
as "adb remount" or "adb disable-verify".

This is a highly insecure magisk module.
Don't forget to disable it once you've done all the things you need.
Don't use it constantly.

This module allows you to run adb daemon from root user. It provides own adbd binary.
The binary obtained from AOSP sources with enhanced patches that disable props
checks, usb auth, minijail restrictions, and modern security features. 
The binary is required because "adb root" can be disabled in compile time by some vendors.
Aarch64 only.

## Key Enhancements for Android 11/12+

- Bypasses minijail privilege dropping mechanisms
- Handles enhanced SELinux policies
- Disables new security property checks
- Maintains compatibility with Android 9/10

## How to install:

Stable release:
1. Download latest adb_root_enhanced.zip from releases page
2. MagiskManager -> Modules + Downloads/adb_root_enhanced.zip -> Reboot

Master branch:
1. git clone https://github.com/evdenis/adb_root_enhanced
2. cd adb_root_enhanced
3. make install

## Support

- Telegram: https://t.me/joinchat/GsJfBBaxozXvVkSJhm0IOQ
- Based on original: https://github.com/evdenis/adb_root